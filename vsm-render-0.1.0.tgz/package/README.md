# VSM Renderer

A Konva-based rendering library for Viable System Model (VSM) diagrams. Implements the NOTATION.md specification precisely.

## Installation

```bash
pnpm add vsm-render
```

## Usage

### Basic Example

```typescript
import { VsmRenderer, VsmSystem, VsmEvent } from 'vsm-render';

const system: VsmSystem = {
  id: 'my-system',
  name: 'My VSM',
  s1: [
    { id: 's1a', name: 'Operations A', operation: { id: 'op-a' }, management: { id: 'mgmt-a' } },
  ],
  metasystem: {
    s2: { id: 's2' },
    s3: { id: 's3' },
    s3star: { id: 's3star' },
    s4: { id: 's4' },
    s5: { id: 's5' },
  },
  environments: [{ id: 'env-a', s1Id: 's1a' }],
  futureEnvironment: { id: 'future-env' },
};

const renderer = new VsmRenderer({
  container: '#vsm-container',
  system: system,
  onEvent: (event: VsmEvent) => {
    console.log('VSM Event:', event.type);
  },
});
```

### Recursive/Nested VSM Example

Each S1 unit can itself be a complete VSM. Click on an S1 unit to drill down into its nested VSM:

```typescript
import { VsmRenderer, VsmSystem, S1Unit, VsmEvent } from 'vsm-render';

// Create a nested S1 unit with its own VSM
const nestedS1Unit: S1Unit = {
  id: 's1a',
  name: 'Operations A',
  operation: { id: 'op-a' },
  management: { id: 'mgmt-a' },
  children: {
    id: 's1a-vsm',
    name: 'Operations A - Internal VSM',
    s1: [
      {
        id: 's1a-1',
        name: 'Sub-Unit A1',
        operation: { id: 'op-a1' },
        management: { id: 'mgmt-a1' },
      },
      {
        id: 's1a-2',
        name: 'Sub-Unit A2',
        operation: { id: 'op-a2' },
        management: { id: 'mgmt-a2' },
      },
    ],
    metasystem: {
      s2: { id: 's1a-s2', name: 'Coordination' },
      s3: { id: 's1a-s3', name: 'Control' },
      s3star: { id: 's1a-s3star', name: 'Audit' },
      s4: { id: 's1a-s4', name: 'Intelligence' },
      s5: { id: 's1a-s5', name: 'Policy' },
    },
    environments: [
      { id: 's1a-env-1', s1Id: 's1a-1', name: 'Env A1' },
      { id: 's1a-env-2', s1Id: 's1a-2', name: 'Env A2' },
    ],
    futureEnvironment: { id: 's1a-future', name: 'Future Env A' },
  },
};

// Top-level VSM with nested S1 unit
const system: VsmSystem = {
  id: 'my-system',
  name: 'My Organization VSM',
  s1: [
    nestedS1Unit,
    { id: 's1b', name: 'Operations B', operation: { id: 'op-b' }, management: { id: 'mgmt-b' } },
  ],
  metasystem: {
    s2: { id: 's2' },
    s3: { id: 's3' },
    s3star: { id: 's3star' },
    s4: { id: 's4' },
    s5: { id: 's5' },
  },
  environments: [
    { id: 'env-a', s1Id: 's1a' },
    { id: 'env-b', s1Id: 's1b' },
  ],
  futureEnvironment: { id: 'future-env' },
};

const renderer = new VsmRenderer({
  container: '#vsm-container',
  system: system,
  onEvent: (event: VsmEvent) => {
    if (event.type === 'drillDown') {
      // Navigate into the nested VSM
      console.log('Drilling down into:', event.unit.name);
    }
    if (event.type === 'drillUp') {
      // Navigate back to parent VSM
      console.log('Drilling up to parent');
    }
  },
});
```

## Features

- Modular architecture with component-based renderers
- Full VSM specification support (S1-S5, S3*, S2)
- Environment rendering with organic shapes
- All 7 channels (a-g) with toggleable visibility
- Zoom and pan interactions
- Drill-down navigation for recursive S1 units
- Eye-loops (amplifier/attenuator arcs)
- S5 dampening arms
- Homeostat balance arrows

## Architecture

```
src/
├── VsmRenderer.ts           # Main integration class
├── index.ts                # Public API exports
├── types.ts               # Type definitions
├── layout/
│   ├── constants.ts        # Layout constants
│   └── index.ts           # Layout helpers
├── renderers/
│   ├── ChannelRenderer.ts   # Channels a-g
│   ├── EnvironmentRenderer.ts # Environment + eye-loops
│   ├── MetasystemRenderer.ts  # S2-S5, triangles, connectors
│   ├── TopLayerRenderer.ts    # S5 arms, homeostat
│   └── UnitsRenderer.ts       # S1 units (circles + squares)
└── utils/
    ├── geometry.ts          # Shape generators
    └── palette.ts           # Color definitions
```

## Development

```bash
pnpm run dev          # Start demo development server
pnpm run build        # Build library
pnpm run build:demo   # Build demo
pnpm run test         # Run tests
pnpm run typecheck    # Type check
```

## License

EUPL-1.2
