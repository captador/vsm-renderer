# VSM Notation Standard

**Version:** 1.0  
**License:** EUPL-1.2

This document is the authoritative, **implementation-independent** specification for rendering the Viable System Model (VSM). Any rendering library — React, Vue, Canvas, SVG, PDF — that claims VSM Notation 1.0 compliance must conform to this spec.

---

## 1. Non-negotiable principles

1. **Recursion-first.** The VSM is one structure repeated at every scale, not a 5-box hierarchy. Every level renders identically; navigating between levels is the core interaction.
2. **Never omit System 3\*.** Systems are **1, 2, 3, 3\*, 4, 5**. A diagram without 3\* is incorrect.
3. **Pixel-faithful shapes.** Use the exact shapes, sides, and colours specified below. Do not invent new visual elements.
4. **Not an org chart.** Recursion levels are containment (viable systems inside viable systems), not command hierarchy.
5. **Distinguish S1 from support.** Operational units (S1) and support functions (S2–S5) are categorically different.

---

## 2. Systems — semantics

| System | Name              | Role                                                                                             |
| ------ | ----------------- | ------------------------------------------------------------------------------------------------ |
| S1     | Operations        | Primary value-producing units. Each is itself a complete viable system.                          |
| S2     | Coordination      | Damps oscillation and conflict between S1 units (shared standards, scheduling).                  |
| S3     | Control           | Runs the inside as a whole; allocates resources; optimises the S1 collective.                    |
| S3\*   | Audit             | Sporadic direct probe into operations that **bypasses** the command line to verify ground truth. |
| S4     | Intelligence      | Looks outside and ahead; models the future; adapts.                                              |
| S5     | Policy / Identity | Ethos, identity, final arbiter; balances S3 (now) vs S4 (future).                                |

**Groupings:** S1+S2+S3+S3\* = _operative management_. S3↔S4 = _strategic_. S5 = _normative_.

---

## 3. Visual element catalog

Draw each element exactly as specified. **Sides matter:** S3\* is always LEFT, S2 is always RIGHT.

### 3.1 Metasystem nodes (one per level)

| Element    | Shape                               | Fill      | Label         | Notes                                                                          |
| ---------- | ----------------------------------- | --------- | ------------- | ------------------------------------------------------------------------------ |
| System 5   | Rounded rectangle, wide             | `#A0C0D5` | "5" (white)   | Top of diagram; two arms curve down both sides embracing the operations column |
| System 4   | Rounded rectangle                   | `#7BCA79` | "4" (white)   | Below S5                                                                       |
| System 3   | Rounded rectangle                   | `#FF5534` | "3" (white)   | Below S4                                                                       |
| System 3\* | **Inverted** triangle (▽), tip down | `#FF5534` | "3\*" (white) | **Left side**, below S3                                                        |
| System 2   | **Upward** triangle (△), tip up     | `#FFCC50` | "2" (white)   | **Right side**, below S3                                                       |

### 3.2 Operational nodes (one set per S1 unit, repeated N times)

| Element       | Shape             | Fill      | Stroke    | Label                       |
| ------------- | ----------------- | --------- | --------- | --------------------------- |
| S1 management | Circle            | `#FFFFFF` | `#9A9A9A` | —                           |
| S1 operation  | Rounded rectangle | `#FFFFFF` | `#9A9A9A` | "1a", "1b", … (unit letter) |

### 3.3 Environment nodes

| Element             | Shape                      | Fill                     | Notes                                            |
| ------------------- | -------------------------- | ------------------------ | ------------------------------------------------ |
| Outer environment   | Large organic amoeba/cloud | `#D7D7D7` at 50% opacity | Encompasses all S1 sub-environments              |
| S1 sub-environment  | Organic blob per unit      | `#8F8F8F`                | One per S1 unit; positioned left of the unit row |
| Future environment  | Organic cloud              | `#A2DAA0`                | Top of environment column; scanned by S4         |
| Environment overlap | Amber lens/eye shape       | `#FFCC50`                | Between adjacent S1 sub-environments             |

---

## 4. Color palette (exact hex values)

```
System 5 / Policy         #A0C0D5  (light blue)
System 4 / Intelligence   #7BCA79  (green)
System 3 / Control        #FF5534  (red — also S3*)
System 2 / Coordination   #FFCC50  (amber — also resource ladder, squiggles, env overlaps)
Future environment        #A2DAA0  (pale green)
Navy connectors           #1D3880
Environment amoeba outer  #D7D7D7
S1 sub-environment blobs  #8F8F8F
Element stroke / outlines #9A9A9A
S1 operation / mgmt fill  #FFFFFF
Amplifier arrows          #333333
White labels on shapes    #FFFFFF
Algedonic bypass          #C0399F  (magenta)
```

---

## 5. Communication channels (a–g)

Channels are the connective tissue of the VSM. Each must be **independently toggleable**.

| ID    | Name                     | Visual                                                                           | Color     | Connects                           |
| ----- | ------------------------ | -------------------------------------------------------------------------------- | --------- | ---------------------------------- |
| **a** | Environmental overlaps   | Amber lens shape (filled ellipse)                                                | `#FFCC50` | Adjacent S1 sub-environments       |
| **b** | System 3\* audit         | Line from S3\* triangle down + horizontal branch into each s1 operational circle | `#FF5534` | S3\* → each S1 ops circle          |
| **c** | Operational dependencies | Direct wavy arrows between adjacent S1 ops circles                               | `#1D3880` | Adjacent S1 ops circles vertically |
| **d** | Resource bargain         | Vertical line (resource channel) with horizontal rung at each S1 mgmt block row  | `#FF5534` | S3 ↔ each S1 unit                  |
| **e** | Command / intervention   | Double (or thick) vertical red line centre                                       | `#FF5534` | S3 → all S1 operation squares      |
| **f** | S2 coordination          | Line from S2 triangle down + horizontal branch into each s1 mgmt circle          | `#FFCC50` | S2 → each S1                       |
| **g** | Algedonic bypass         | Dashed magenta path, default off                                                 | `#C0399F` | Last S1 → S5 (emergency bypass)    |

**Additional structural connectors** (always visible, not toggled):

| Name                   | Visual                          | Color                           | Connects                             |
| ---------------------- | ------------------------------- | ------------------------------- | ------------------------------------ |
| S3↔S4 homeostat        | Cubic Bézier curls              | Red `#FF5534` + Green `#7BCA79` | S3 ↔ S4 (bidirectional)              |
| S5 arms                | Curved paths                    | `#A0C0D5`                       | S5 rectangle curling down both sides |
| S4 ↔ future env        | Double-headed Bézier arcs       | `#7BCA79`                       | S4 ↔ future environment blob         |
| Amplifier / attenuator | Double-headed horizontal arrows | `#333333`                       | Each S1 env blob ↔ its mgmt circle   |
| S3→S3\* feed           | Elbow line                      | `#FF5534`                       | S3 bar → S3\* triangle               |
| S3→S2 feed             | Elbow line                      | `#FFCC50`                       | S3 bar → S2 triangle                 |

---

## 6. Canonical layout

Use a **portrait** canvas with approximate proportions matching `viewBox="0 0 900 1100"`. Three columns:

```
┌──────────────┬────────────────────────────────────┐
│ ENVIRONMENT  │          THE SYSTEM (R0)           │
│  (~30% wide) │                                    │
│              │   ┌──────── S5 ───────┐            │  ← wide rounded rect; arms curve down
│  green cloud ◄── │──┌───── S4 ────┐  │            │
│  (future)    │   └──└───── S3 ────┘──┘ [homeostat]│
│              │   ▽ S3*    ║ ↕ ║     S2 △          │  ← S3* LEFT, S2 RIGHT
│  gray amoeba │   │        ║ ↕ ║        │          │
│  ┌─blob 1a◄──┼──►  ○ op ── □ mgmt ─────┘          │
│  ✦ overlap  │   │  ⌇     ║ ↕ ║        │          │
│  ┌─blob 1b◄──┼──►  ○ op ── □ mgmt ─────┘          │
│  ✦ overlap  │   │  ⌇     ║ ↕ ║        │          │
│  └─blob 1c◄──┼──►  ○ op ── □ mgmt ─────┘          │
└──────────────┴────────────────────────────────────┘
                    ↑ amplifier/attenuator arrows (double-headed, black)
```

**Vertical order top→bottom:** S5 → S4 → S3 → (S3\* left, S2 right) → S1 units stack.

---

## 7. Recursion model

- **R+1**: the system that contains the current one.
- **R0**: the **System in Focus (SIF)** — the level currently rendered.
- **R-1**: the S1 sub-units; each unfolds into its own full VSM.
- **Drill down**: clicking an S1 operation makes that unit become the new R0.
- **Zoom out**: navigating to an ancestor makes the current R0 become an S1 of R+1.
- **Breadcrumb**: always show `R+1 ▸ R0 (SIF) ▸ R-1` path.
- **Self-similarity**: every level renders with the identical structure. No special top level.

---

## 8. Structural constraints

- **Exactly one** S2, S3, S3\*, S4, S5 node per recursion level.
- **Exactly one** future-environment node per recursion level.
- **N ≥ 1** S1 units and corresponding sub-environment nodes (N determines the layout height).
- S1 units are labelled 1a, 1b, 1c, … (alpha suffix, wrapping after z).

---

## 9. Info-panel copy (per element)

| Element              | Copy                                                                                                                         |
| -------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| S5 — Policy/Identity | Ultimate authority and identity. Sets policy, holds the ethos, balances present (S3) vs future (S4). Governs by exception.   |
| S4 — Intelligence    | Scans the outside and the future; models options; adapts. Bridges the inside (S3) with the environment.                      |
| S3 — Control         | Runs the whole S1 complex here and now; allocates resources; drives synergy.                                                 |
| S3\* — Audit         | Sporadic, direct probe into operations that bypasses the command line to verify reality. Without it, S3 has no check.        |
| S2 — Coordination    | Damps oscillation and conflict between units via shared standards and scheduling. Reduces load on S3.                        |
| S1 — Operation       | A primary value-producing unit. Itself a complete viable system — click to unfold.                                           |
| Environment          | Each unit has its own local environment; these overlap (amber lenses). S4 additionally scans the future environment (green). |

---
